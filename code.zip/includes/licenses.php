<?php
/**
 * StarForge - Complete GitHub Licenses Directory
 * Standard open source licenses available on GitHub and SPDX.
 */

function get_github_licenses(): array {
    return [
        [
            'id' => 'MIT',
            'name' => 'MIT License',
            'category' => 'permissive',
            'popular' => true,
            'summary' => 'Short, simple, and permissive. Lets anyone do anything with your code as long as they include your copyright and license notice.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Private use'],
            'conditions' => ['License & copyright notice'],
            'limitations' => ['No liability', 'No warranty']
        ],
        [
            'id' => 'Apache-2.0',
            'name' => 'Apache License 2.0',
            'category' => 'permissive',
            'popular' => true,
            'summary' => 'Permissive license that provides an explicit grant of patent rights from contributors to users and protects trademarks.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Patent grant', 'Private use'],
            'conditions' => ['License & copyright notice', 'State changes'],
            'limitations' => ['No liability', 'No trademark rights']
        ],
        [
            'id' => 'GPL-3.0',
            'name' => 'GNU General Public License v3.0',
            'category' => 'copyleft',
            'popular' => true,
            'summary' => 'Strong copyleft license. Anyone who distributes modified versions or derivative works must make source code available under GPLv3.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Patent grant'],
            'conditions' => ['Disclose source', 'License & copyright notice', 'Same license (Copyleft)', 'State changes'],
            'limitations' => ['No liability', 'No warranty']
        ],
        [
            'id' => 'GPL-2.0',
            'name' => 'GNU General Public License v2.0',
            'category' => 'copyleft',
            'popular' => true,
            'summary' => 'Legacy copyleft license made famous by the Linux kernel. Derivative works must be published under the same license terms.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution'],
            'conditions' => ['Disclose source', 'License & copyright notice', 'Same license', 'State changes'],
            'limitations' => ['No liability', 'No warranty']
        ],
        [
            'id' => 'BSD-3-Clause',
            'name' => 'BSD 3-Clause "New" or "Revised" License',
            'category' => 'permissive',
            'popular' => true,
            'summary' => 'Similar to MIT, with an additional clause prohibiting the use of contributor names for endorsement or promotion without written consent.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Private use'],
            'conditions' => ['License & copyright notice'],
            'limitations' => ['No liability', 'No warranty', 'No endorsement']
        ],
        [
            'id' => 'BSD-2-Clause',
            'name' => 'BSD 2-Clause "Simplified" License',
            'category' => 'permissive',
            'popular' => false,
            'summary' => 'Minimal permissive license with a two-clause disclaimer of liability and warranty.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Private use'],
            'conditions' => ['License & copyright notice'],
            'limitations' => ['No liability', 'No warranty']
        ],
        [
            'id' => '0BSD',
            'name' => 'BSD Zero Clause License',
            'category' => 'public-domain',
            'popular' => false,
            'summary' => 'Allows unlimited freedom with software without any requirements for attribution or copyright retention.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Private use'],
            'conditions' => ['None'],
            'limitations' => ['No liability', 'No warranty']
        ],
        [
            'id' => 'BSD-3-Clause-Clear',
            'name' => 'BSD 3-Clause Clear License',
            'category' => 'permissive',
            'popular' => false,
            'summary' => 'BSD 3-Clause license with an explicit non-grant of patent rights.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Private use'],
            'conditions' => ['License & copyright notice'],
            'limitations' => ['No liability', 'No warranty', 'No patent grant', 'No endorsement']
        ],
        [
            'id' => 'BSD-4-Clause',
            'name' => 'BSD 4-Clause "Original" License',
            'category' => 'permissive',
            'popular' => false,
            'summary' => 'Historical BSD license with the original advertising clause requiring acknowledgment in all promotional materials.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution'],
            'conditions' => ['License & copyright notice', 'Advertising clause acknowledgment'],
            'limitations' => ['No liability', 'No warranty']
        ],
        [
            'id' => 'AGPL-3.0',
            'name' => 'GNU Affero General Public License v3.0',
            'category' => 'copyleft',
            'popular' => true,
            'summary' => 'Network copyleft. Running modified code over a network (SaaS/cloud) triggers the requirement to release source code to users.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Network use'],
            'conditions' => ['Disclose network source', 'License & copyright notice', 'Same license', 'State changes'],
            'limitations' => ['No liability', 'No warranty']
        ],
        [
            'id' => 'LGPL-3.0',
            'name' => 'GNU Lesser General Public License v3.0',
            'category' => 'weak-copyleft',
            'popular' => false,
            'summary' => 'Weak copyleft primarily for libraries. Applications that merely link to the library do not need to share their source code.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Patent grant'],
            'conditions' => ['Disclose library source', 'License & copyright notice', 'Same license for library'],
            'limitations' => ['No liability', 'No warranty']
        ],
        [
            'id' => 'LGPL-2.1',
            'name' => 'GNU Lesser General Public License v2.1',
            'category' => 'weak-copyleft',
            'popular' => false,
            'summary' => 'Legacy weak copyleft license allowing proprietary programs to link dynamically or statically to the library.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution'],
            'conditions' => ['Disclose library source', 'License & copyright notice'],
            'limitations' => ['No liability', 'No warranty']
        ],
        [
            'id' => 'MPL-2.0',
            'name' => 'Mozilla Public License 2.0',
            'category' => 'weak-copyleft',
            'popular' => true,
            'summary' => 'Simple file-level copyleft license. Modifications to MPL files must remain open, but larger works can combine them with proprietary code.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Patent grant'],
            'conditions' => ['Disclose modified files', 'License & copyright notice'],
            'limitations' => ['No liability', 'No trademark rights']
        ],
        [
            'id' => 'Unlicense',
            'name' => 'The Unlicense',
            'category' => 'public-domain',
            'popular' => true,
            'summary' => 'Dedicates works completely to the public domain with zero conditions, copyright waiver, and no warranty.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Private use'],
            'conditions' => ['None'],
            'limitations' => ['No liability', 'No warranty']
        ],
        [
            'id' => 'CC0-1.0',
            'name' => 'Creative Commons Zero v1.0 Universal',
            'category' => 'public-domain',
            'popular' => true,
            'summary' => 'Waives all copyright and related rights worldwide. Recommended for datasets, documentation, templates, and public assets.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Private use'],
            'conditions' => ['None'],
            'limitations' => ['No liability', 'No warranty']
        ],
        [
            'id' => 'CC-BY-4.0',
            'name' => 'Creative Commons Attribution 4.0 International',
            'category' => 'creative-commons',
            'popular' => false,
            'summary' => 'Permits sharing and adapting content for any purpose (even commercial) as long as attribution is provided.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution'],
            'conditions' => ['Attribution required', 'State changes'],
            'limitations' => ['No liability']
        ],
        [
            'id' => 'CC-BY-SA-4.0',
            'name' => 'Creative Commons Attribution-ShareAlike 4.0',
            'category' => 'creative-commons',
            'popular' => false,
            'summary' => 'Copyleft for creative content. Allows sharing and adapting with credit, under the same license terms.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution'],
            'conditions' => ['Attribution required', 'ShareAlike (Same license)'],
            'limitations' => ['No liability']
        ],
        [
            'id' => 'ISC',
            'name' => 'ISC License',
            'category' => 'permissive',
            'popular' => false,
            'summary' => 'Permissive license functionally equivalent to the two-clause BSD and MIT licenses with simplified language (used by npm/OpenBSD).',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Private use'],
            'conditions' => ['License & copyright notice'],
            'limitations' => ['No liability', 'No warranty']
        ],
        [
            'id' => 'BSL-1.0',
            'name' => 'Boost Software License 1.0',
            'category' => 'permissive',
            'popular' => false,
            'summary' => 'Permissive license designed for C++ libraries. Does not require attribution when distributing compiled binary forms.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Private use'],
            'conditions' => ['License & copyright notice on source distributions'],
            'limitations' => ['No liability', 'No warranty']
        ],
        [
            'id' => 'EPL-2.0',
            'name' => 'Eclipse Public License 2.0',
            'category' => 'weak-copyleft',
            'popular' => false,
            'summary' => 'Commercial-friendly copyleft license by Eclipse Foundation with clear patent grants and file-level copyleft.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Patent grant'],
            'conditions' => ['Disclose source', 'License & copyright notice'],
            'limitations' => ['No liability']
        ],
        [
            'id' => 'EPL-1.0',
            'name' => 'Eclipse Public License 1.0',
            'category' => 'weak-copyleft',
            'popular' => false,
            'summary' => 'Legacy version of Eclipse Public License common across Java and JVM ecosystems.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Patent grant'],
            'conditions' => ['Disclose source', 'License & copyright notice'],
            'limitations' => ['No liability']
        ],
        [
            'id' => 'MIT-0',
            'name' => 'MIT No Attribution',
            'category' => 'public-domain',
            'popular' => false,
            'summary' => 'Variation of MIT license that completely removes the requirement to include copyright notices in distributions.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Private use'],
            'conditions' => ['None'],
            'limitations' => ['No liability', 'No warranty']
        ],
        [
            'id' => 'BlueOak-1.0.0',
            'name' => 'Blue Oak Model License 1.0.0',
            'category' => 'permissive',
            'popular' => false,
            'summary' => 'Modern, plain-English permissive license crafted by software attorneys to replace legacy licenses with clear prose.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Patent grant'],
            'conditions' => ['License & copyright notice'],
            'limitations' => ['No liability']
        ],
        [
            'id' => 'OFL-1.1',
            'name' => 'SIL Open Font License 1.1',
            'category' => 'special',
            'popular' => false,
            'summary' => 'Specialized open source license for fonts and typography, allowing fonts to be bundled or distributed freely.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Embedding'],
            'conditions' => ['License & copyright notice', 'Do not sell standalone font file'],
            'limitations' => ['No liability']
        ],
        [
            'id' => 'EUPL-1.2',
            'name' => 'European Union Public Licence 1.2',
            'category' => 'copyleft',
            'popular' => false,
            'summary' => 'European copyleft license legally binding in 23 EU languages with explicit compatibility across GPL, MPL, and LGPL.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Patent grant'],
            'conditions' => ['Disclose source', 'License & copyright notice', 'Same license'],
            'limitations' => ['No liability']
        ],
        [
            'id' => 'Zlib',
            'name' => 'zlib License',
            'category' => 'permissive',
            'popular' => false,
            'summary' => 'Short permissive license used by zlib, libpng, and several game engines. Does not require attribution in binary code.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Private use'],
            'conditions' => ['Do not misrepresent origin', 'Altered source versions must be marked'],
            'limitations' => ['No liability']
        ],
        [
            'id' => 'OSL-3.0',
            'name' => 'Open Software License 3.0',
            'category' => 'copyleft',
            'popular' => false,
            'summary' => 'OSI-approved reciprocal license with explicit patent licensing and network distribution clauses.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Patent grant'],
            'conditions' => ['Disclose source', 'License & copyright notice', 'State changes'],
            'limitations' => ['No liability']
        ],
        [
            'id' => 'Artistic-2.0',
            'name' => 'Artistic License 2.0',
            'category' => 'permissive',
            'popular' => false,
            'summary' => 'Open source license used primarily by the Perl community and CRAN R packages.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Private use'],
            'conditions' => ['License & copyright notice', 'State changes'],
            'limitations' => ['No liability']
        ],
        [
            'id' => 'MS-PL',
            'name' => 'Microsoft Public License',
            'category' => 'permissive',
            'popular' => false,
            'summary' => 'Permissive Microsoft open source license that grants copyright and patent licenses to reproduce and distribute code.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Patent grant'],
            'conditions' => ['License & copyright notice'],
            'limitations' => ['No liability', 'No trademark rights']
        ],
        [
            'id' => 'MS-RL',
            'name' => 'Microsoft Reciprocal License',
            'category' => 'copyleft',
            'popular' => false,
            'summary' => 'Copyleft Microsoft license; redistributing modified files requires releasing the file source code under MS-RL.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Patent grant'],
            'conditions' => ['Disclose modified files', 'License & copyright notice'],
            'limitations' => ['No liability', 'No trademark rights']
        ],
        [
            'id' => 'WTFPL',
            'name' => 'Do What The F*ck You Want To Public License',
            'category' => 'public-domain',
            'popular' => false,
            'summary' => 'Informal, ultra-permissive anti-copyright license that simply gives unrestricted freedom.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Private use'],
            'conditions' => ['None'],
            'limitations' => ['No liability', 'No warranty']
        ],
        [
            'id' => 'PostgreSQL',
            'name' => 'PostgreSQL License',
            'category' => 'permissive',
            'popular' => false,
            'summary' => 'Simple liberal open source license similar to MIT or BSD, used by PostgreSQL and related ecosystem packages.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Private use'],
            'conditions' => ['License & copyright notice'],
            'limitations' => ['No liability', 'No warranty']
        ],
        [
            'id' => 'NCSA',
            'name' => 'University of Illinois/NCSA Open Source License',
            'category' => 'permissive',
            'popular' => false,
            'summary' => 'Permissive license combining terms from MIT and BSD, used extensively by LLVM and Clang.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Private use'],
            'conditions' => ['License & copyright notice'],
            'limitations' => ['No liability', 'No warranty', 'No endorsement']
        ],
        [
            'id' => 'UPL-1.0',
            'name' => 'Universal Permissive License 1.0',
            'category' => 'permissive',
            'popular' => false,
            'summary' => 'Permissive open source license with explicit dual copyright and patent grant provisions.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Patent grant'],
            'conditions' => ['License & copyright notice'],
            'limitations' => ['No liability', 'No warranty']
        ],
        [
            'id' => 'Vim',
            'name' => 'Vim License',
            'category' => 'permissive',
            'popular' => false,
            'summary' => 'Permissive charityware license used by Vim that encourages donations to children in Uganda.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution'],
            'conditions' => ['License notice', 'Supply modification notice'],
            'limitations' => ['No liability']
        ],
        [
            'id' => 'MulanPSL-2.0',
            'name' => 'Mulan Permissive Software License v2',
            'category' => 'permissive',
            'popular' => false,
            'summary' => 'Bilingual (English & Chinese) permissive license with express patent grant recognized by OSI and OpenAtom.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Patent grant'],
            'conditions' => ['License & copyright notice'],
            'limitations' => ['No liability', 'No warranty']
        ],
        [
            'id' => 'CERN-OHL-P-2.0',
            'name' => 'CERN Open Hardware Licence v2 - Permissive',
            'category' => 'special',
            'popular' => false,
            'summary' => 'Permissive license tailored for open hardware designs, documentation, and hardware schematics.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Hardware fabrication'],
            'conditions' => ['Notice preservation'],
            'limitations' => ['No liability']
        ],
        [
            'id' => 'CERN-OHL-S-2.0',
            'name' => 'CERN Open Hardware Licence v2 - Strongly Reciprocal',
            'category' => 'copyleft',
            'popular' => false,
            'summary' => 'Strongly reciprocal copyleft hardware license requiring full design files to be published.',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution', 'Hardware fabrication'],
            'conditions' => ['Disclose design files', 'Same license'],
            'limitations' => ['No liability']
        ],
        [
            'id' => 'ODbL-1.0',
            'name' => 'Open Database License 1.0',
            'category' => 'special',
            'popular' => false,
            'summary' => 'Copyleft database license allowing users to freely share, modify, and use databases (used by OpenStreetMap).',
            'permissions' => ['Commercial use', 'Modifications', 'Distribution'],
            'conditions' => ['Attribution', 'ShareAlike', 'Keep open'],
            'limitations' => ['No liability']
        ]
    ];
}

function get_license_by_id(string $id): ?array {
    $licenses = get_github_licenses();
    foreach ($licenses as $lic) {
        if (strcasecmp($lic['id'], $id) === 0) {
            return $lic;
        }
    }
    return null;
}
